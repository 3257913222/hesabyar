package com.hesabyar.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

private const val NAVY = 0xFF102B35.toInt()
private const val GREEN = 0xFF087F5B.toInt()
private const val GOLD = 0xFFD6A84F.toInt()
private const val BG = 0xFFF3F6F5.toInt()
private const val INK = 0xFF1D3435.toInt()

class TxDb(ctx: android.content.Context) : SQLiteOpenHelper(ctx, "hesabyar.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE tx (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, amount INTEGER NOT NULL, kind TEXT NOT NULL, created INTEGER NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun add(title: String, amount: Long, kind: String) {
        writableDatabase.execSQL(
            "INSERT INTO tx(title,amount,kind,created) VALUES(?,?,?,strftime('%s','now'))",
            arrayOf(title, amount, kind)
        )
    }
    fun all(): List<Tx> {
        val out = mutableListOf<Tx>()
        readableDatabase.rawQuery("SELECT id,title,amount,kind FROM tx ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) out.add(Tx(c.getLong(0), c.getString(1), c.getLong(2), c.getString(3)))
        }
        return out
    }
    fun delete(id: Long) { writableDatabase.delete("tx", "id=?", arrayOf(id.toString())) }
}
data class Tx(val id: Long, val title: String, val amount: Long, val kind: String)

class MainActivity : Activity() {
    private lateinit var db: TxDb
    private lateinit var content: LinearLayout
    private lateinit var incomeText: TextView
    private lateinit var expenseText: TextView
    private lateinit var balanceText: TextView
    private val money = DecimalFormat("#,###", DecimalFormatSymbols(Locale.US))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = TxDb(this)
        window.statusBarColor = NAVY
        window.navigationBarColor = NAVY
        buildUi()
        refresh()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(BG) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(28))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        scroll.addView(page)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
            background = rounded(NAVY, 22)
        }
        header.addView(text("حساب‌یار", 27, Color.WHITE, true))
        header.addView(text("حساب‌وکتاب ساده، همیشه همراه شما", 14, 0xFFDCE9E5.toInt(), false))
        page.addView(header, matchWrap())

        val totals = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(14))
        }
        incomeText = totalCard("درآمد", GREEN)
        expenseText = totalCard("هزینه", 0xFFB54747.toInt())
        balanceText = totalCard("مانده", NAVY)
        totals.addView(incomeText, LinearLayout.LayoutParams(0, dp(92), 1f).apply { marginEnd = dp(5) })
        totals.addView(expenseText, LinearLayout.LayoutParams(0, dp(92), 1f).apply { marginStart = dp(5); marginEnd = dp(5) })
        totals.addView(balanceText, LinearLayout.LayoutParams(0, dp(92), 1f).apply { marginStart = dp(5) })
        page.addView(totals)

        page.addView(text("ثبت تراکنش جدید", 19, INK, true).apply { setPadding(0, dp(8), 0, dp(8)) })
        val titleInput = EditText(this).apply {
            hint = "عنوان (مثلاً خرید مواد غذایی)"
            textSize = 15f
            setSingleLine(true)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = rounded(Color.WHITE, 12)
        }
        page.addView(titleInput, matchWrap())
        val amountInput = EditText(this).apply {
            hint = "مبلغ به تومان"
            textSize = 15f
            inputType = 2
            setSingleLine(true)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = rounded(Color.WHITE, 12)
        }
        val amountParams = matchWrap()
        amountParams.topMargin = dp(9)
        page.addView(amountInput, amountParams)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, dp(16)) }
        val addIncome = Button(this).apply {
            text = "ثبت درآمد"; setTextColor(Color.WHITE); textSize = 14f
            setBackgroundColor(GREEN)
            setOnClickListener { saveTx(titleInput, amountInput, "IN") }
        }
        val addExpense = Button(this).apply {
            text = "ثبت هزینه"; setTextColor(Color.WHITE); textSize = 14f
            setBackgroundColor(0xFFB54747.toInt())
            setOnClickListener { saveTx(titleInput, amountInput, "OUT") }
        }
        actions.addView(addIncome, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginEnd = dp(5) })
        actions.addView(addExpense, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginStart = dp(5) })
        page.addView(actions)

        page.addView(text("تراکنش‌های اخیر", 19, INK, true).apply { setPadding(0, dp(4), 0, dp(10)) })
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(content, matchWrap())
        page.addView(text("اطلاعات فقط روی همین گوشی ذخیره می‌شود؛ این نسخه برای آزمایش اولیه و بدون نیاز به اینترنت است.", 12, 0xFF60716D.toInt(), false).apply { setPadding(0, dp(18), 0, 0) })
        setContentView(scroll)
    }

    private fun saveTx(title: EditText, amount: EditText, kind: String) {
        val t = title.text.toString().trim()
        val a = amount.text.toString().trim().replace(",", "").toLongOrNull()
        if (t.isEmpty() || a == null || a <= 0) {
            Toast.makeText(this, "عنوان و مبلغ معتبر را وارد کنید.", Toast.LENGTH_SHORT).show()
            return
        }
        db.add(t, a, kind)
        title.text.clear(); amount.text.clear()
        refresh()
        Toast.makeText(this, "تراکنش ذخیره شد.", Toast.LENGTH_SHORT).show()
    }

    private fun refresh() {
        val list = db.all()
        val income = list.filter { it.kind == "IN" }.sumOf { it.amount }
        val expense = list.filter { it.kind == "OUT" }.sumOf { it.amount }
        incomeText.text = "درآمد\n${money.format(income)}"
        expenseText.text = "هزینه\n${money.format(expense)}"
        balanceText.text = "مانده\n${money.format(income - expense)}"
        content.removeAllViews()
        if (list.isEmpty()) {
            content.addView(TextView(this).apply {
                text = "هنوز تراکنشی ثبت نشده است."
                textSize = 14f; setTextColor(0xFF71817D.toInt()); gravity = Gravity.CENTER
                setPadding(dp(12), dp(24), dp(12), dp(24)); background = rounded(Color.WHITE, 14)
            }, matchWrap())
        } else {
            list.forEach { item ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(13), dp(12), dp(8), dp(12)); background = rounded(Color.WHITE, 14)
                }
                val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                info.addView(text(item.title, 15, INK, true))
                val label = if (item.kind == "IN") "درآمد" else "هزینه"
                val color = if (item.kind == "IN") GREEN else 0xFFB54747.toInt()
                info.addView(text("$label  •  ${money.format(item.amount)} تومان", 13, color, false))
                row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
                val del = Button(this).apply {
                    text = "حذف"; textSize = 12f; setTextColor(Color.WHITE)
                    setBackgroundColor(0xFF7B8582.toInt())
                    setOnClickListener {
                        db.delete(item.id); refresh()
                        Toast.makeText(this@MainActivity, "تراکنش حذف شد.", Toast.LENGTH_SHORT).show()
                    }
                }
                row.addView(del, LinearLayout.LayoutParams(dp(62), dp(42)))
                val p = matchWrap(); p.bottomMargin = dp(8)
                content.addView(row, p)
            }
        }
    }

    private fun totalCard(label: String, color: Int) = TextView(this).apply {
        text = label; textSize = 13f; typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER; setTextColor(Color.WHITE); setPadding(dp(3), dp(8), dp(3), dp(8))
        background = rounded(color, 14)
    }
    private fun text(s: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.RIGHT; textDirection = View.TEXT_DIRECTION_RTL
    }
    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
